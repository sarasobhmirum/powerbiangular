function assert(exp){
  if(console["assert"]){
      console.assert(exp);
  }
}