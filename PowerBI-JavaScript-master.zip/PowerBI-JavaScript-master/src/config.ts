// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

/** @ignore *//** */
const config = {
  version: '2.18.0',
  type: 'js'
};

export default config;
